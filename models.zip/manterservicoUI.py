import streamlit as st
import pandas as pd
from Agenda.views import View
import time

class ManterServicoUI:
    def main():
        st.header("Cadastro de Serviços")